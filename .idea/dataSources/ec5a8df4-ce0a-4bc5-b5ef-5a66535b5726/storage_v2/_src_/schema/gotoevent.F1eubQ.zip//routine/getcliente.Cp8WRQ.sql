create procedure getcliente(IN email varchar(50), IN password varchar(20))
  begin
select cli.* from clientes cli inner join usuarios us on cli.id_usuario=us.id_usuario where
us.email=email and us.password=password;
end;

